# Aurora Runtime SDK

`@aurora/sdk` is Aurora's framework-independent deterministic runtime boundary. It loads an
`aurora-project` version 1 bundle through `packages/project-format`, reconstructs supported public
Core artifacts, resolves ProductDNA context, executes declarative RuleSets, projects Decisions, and
returns deeply frozen JSON-safe results.

```ts
const loaded = AuroraRuntime.loadProject(projectJson);
if (!loaded.ok) return loaded;

const result = loaded.runtime.execute({
  ruleSet: { kind: "ruleset", artifactId: "ruleset.example" },
  product: { kind: "product-dna", artifactId: "studio-product-record" },
});
```

Domain output is separate from trace fingerprints and artifact selectors. Runtime instances are
immutable, synchronous, stateless per execution, safe to reuse, and own no cache, file access,
networking, UI, framework, database, or model integration.

## Application integration

`@aurora/sdk/integration` provides `AuroraApplicationService`, JSON-safe request/response DTOs, and
an optional caller-owned `AuroraRuntimeResultCache`. The service validates transport-shaped input,
invokes the runtime, and converts existing deterministic output to plain data; it adds no semantic
mapping. Product records must bind explicitly to a ProductDNA artifact ID.

Only successful responses are cacheable, keyed by the SDK input fingerprint. Applications own
cache lifetime and implementation. Operational logging is opt-in and limited to stage, issue codes,
project/artifact IDs, fingerprints, and duration.
